<div class="alert alert-primary text-center">
    <i class="fe fe-alert-triangle mr-2"></i> @lang('You don\'t have any accounts. Please, <a href=":link">add account</a> to start.', ['link' => route('account.create')])
</div>