## Examples

These examples demonstrate various common tasks and are meant to get you started
with this library.

Many of these files contain a configuration section at the top, which you must
edit to provide your own account and media details before running the example.

## WARNING, PLEASE READ!

If you are viewing this examples-folder via the web, they may not work on the
code version that you have downloaded, since development may evolve quickly in
the development version of the code tree. Especially if you've installed the
default, stable version of the library, which can often be severely out of date.

Look in _your own_ local disk's `vendor/mgp25/instagram-php/examples` folder for
the examples that shipped with the exact library version you have installed!
