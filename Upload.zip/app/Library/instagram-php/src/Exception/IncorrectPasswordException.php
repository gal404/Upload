<?php

namespace InstagramAPI\Exception;

class IncorrectPasswordException extends RequestException
{
}
